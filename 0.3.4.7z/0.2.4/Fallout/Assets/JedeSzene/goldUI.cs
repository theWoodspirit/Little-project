﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class goldUI : MonoBehaviour {

	// Use this for initialization
	public Text goldUItext;
	public Text lvlUItext;
	public Text waveUItext;
	// Update is called once per frame
	void Update () {
		goldUItext.text = "Gold: " + PlayerStats.gold.ToString ();
		waveUItext.text = "Wave: " + PlayerStats.wave.ToString ();
		lvlUItext.text = "LEVEL: "+PlayerStats.lvl.ToString ();
	}
}
