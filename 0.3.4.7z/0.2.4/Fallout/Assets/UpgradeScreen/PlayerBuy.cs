﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class PlayerBuy : MonoBehaviour {

	public bool haveMoney;

	public Text health;
	public static int healthCost=3;
	public Text healthCostText;

	public void upgradeHealth(){
		if (PlayerStats.gold < healthCost) {
			return;
		}
		Debug.Log ("Spieler Leben geupgradet");
		PlayerStats.gold -= healthCost;
		healthCost += 3;
		Player.startHealth += 25;
	}

	public Text atk;
	public static int atkCost = 3;
	public Text atkCostText;

	public void upgradeAtk(){
		if (PlayerStats.gold < atkCost) {
			return;
		}
		Debug.Log ("Spieler Angriff geupgradet");
		PlayerStats.gold -= atkCost;
		atkCost += 3;
		Player.atk += 25;
	}

	public Text range;
	public static int rangeCost=3;
	public Text rangeCostText;

	public void upgradePlayerRange(){
		if (PlayerStats.gold < rangeCost||Player.range>=20) {
			return;
		}
		Debug.Log ("Spieler Range geupgradet");
		PlayerStats.gold -= rangeCost;
		rangeCost += 3;
		Player.range += 1;
	}

	void Update () {
		health.text = "You actually Health is:  " + Player.startHealth;
		atk.text = "You actually Attack is:  " + Player.atk;
		range.text = "You actually Range is:  " + Player.range;

		healthCostText.text = "Next Upgrade Cost: " + PlayerBuy.healthCost.ToString();
		atkCostText.text = "Next Upgrade Cost: " + PlayerBuy.atkCost.ToString ();
		rangeCostText.text = "Next Upgrade Cost: "+PlayerBuy.rangeCost.ToString ();
	}
}