﻿using UnityEngine;
using UnityEngine.UI;

public class Enemy : MonoBehaviour {

	// GEGNER STATS
	public float startSpeed = 1f;
	[HideInInspector]

	public static float startHealth = 100;
	private float health;

	public static float atk=5;
	public static float range=8;

	public float speed=8; // laufgeschwindigkeit? 
	public static float cooltime;
	public static float startcooltime=0.5f;
	public static int wert=2;
	public static int xpWert=1;
	// GEGNER STATS ENDE 

	// buggy !!!!!

	public Transform castle;

	public string PlayerTag = "Player";
	private Transform target;
	private Enemy targetEnemy;
	public GameObject deathEffect;
	[Header("Unity Stuff")]
	private bool isDead = false;
	public RectTransform healthBar;
	// VARIABLEN ENDE

	void Start (){
		speed = startSpeed;
		health = startHealth;
		InvokeRepeating("UpdateTarget", 0f, 0.5f);
	}

	// LEIDEN
	public void TakeDamage (float amount){
		health -= amount;
		//lebensleiste
		healthBar.sizeDelta = new Vector2(health/startHealth * 100, healthBar.sizeDelta.y);
		Debug.Log ("enemy take damage");
		if (health <= 0 && !isDead){
			Die();
		}
	}

	 void Die (){
		isDead = true;
		Debug.Log ("isDead = true");
		PlayerStats.gold += wert;
		PlayerStats.exp += xpWert;
		WaveSpawner.EnemiesAlive--;
		Destroy (gameObject);
	}
	public void Slow (float pct){
		speed = startSpeed * (1f - pct);
	}

	// LEIDEN ENDE

	void dmg(Transform hero){
		Player p = hero.GetComponent<Player>();
		if (p != null){
			p.HeroTakeDamage(atk);
		}
	}
	void dmgCastle(Transform castle){
		Castle c = castle.GetComponent<Castle>();

		if (c != null){
			c.CastleTakeDamage(atk);
		}
	}
	//ANGRIFF ENDE

	// Gegnersuche
	void UpdateTarget (){
		GameObject[] enemies = GameObject.FindGameObjectsWithTag(PlayerTag);
		float shortestDistance = Mathf.Infinity;
		GameObject nearestEnemy = null;
		foreach (GameObject enemy in enemies){
			float distanceToEnemy = Vector3.Distance(transform.position, enemy.transform.position);
			if (distanceToEnemy < shortestDistance){
				shortestDistance = distanceToEnemy;
				nearestEnemy = enemy;
			}
		}

		if (nearestEnemy != null && shortestDistance <= range) {
			target = nearestEnemy.transform;
			targetEnemy = nearestEnemy.GetComponent<Enemy> ();
		} else {
			target = null;
		}
	}


	void Update(){
		if (health == 0) {
			Die ();
		}
		if (Castle.fail == true) {
			return;
		}
		if (target != null) {
			Vector3 displacement = target.position - transform.position;
			displacement = displacement.normalized;
			if (Vector2.Distance (target.position, transform.position) >= range) {
				transform.position += (displacement * speed * Time.deltaTime);
			} else {
				if (cooltime<=0.0) {
					if (target == castle) {
						dmgCastle (castle);
					} else {
						dmg (target);
					}
					cooltime = startcooltime;
				}
			}
		}
		else {
			target = castle;
		}
		cooltime -= Time.deltaTime;
	}
}
