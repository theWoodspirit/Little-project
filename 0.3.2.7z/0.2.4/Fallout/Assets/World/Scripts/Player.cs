﻿using UnityEngine;
using UnityEngine.UI;

public class Player : MonoBehaviour {
	// WERTE 

	[HideInInspector]
	public float startSpeed = 5f;
	public float speed;

	public static float startHealth = 100;
	public static float health;

	public static float atk = 50; 
	public static float range=8;

	public float cooltime;
	public float startcooltime=0.5f;
	// WERTE ENDE


	//VARIABLEN ENDE
	public GameObject deathEffect;
	public RectTransform healthBar;
	public bool heldtod = false;
	public string EnemyTag = "Enemy";
	private Transform target;
	private Enemy targetEnemy;
	// VARIABLEN ENDE

	// VERLETZUNG
	public void HeroTakeDamage (float amount){
		health -= amount;
		// lebensleiste anzeigen
		healthBar.sizeDelta = new Vector2(health/startHealth * 100, healthBar.sizeDelta.y);
		Debug.Log ("hero take damage");
		if (health <= 0 && !heldtod){
			Die();
		}
	}

	public void Slow (float pct){
		speed = startSpeed * (1f - pct);
	}

	void Die (){
		heldtod = true;
		//GameObject effect = (GameObject)Instantiate(deathEffect, transform.position, Quaternion.identity);
		//Destroy(effect, 5f);
		Destroy(gameObject);
	}
	// VERLETZUNG ENDE

	//ANGRIFF
	void dmg(Transform enemy){
		Enemy e = enemy.GetComponent<Enemy>();

		if (e != null){
			e.TakeDamage(atk);
		}
	}

	void UpdateTarget (){
		GameObject[] enemies = GameObject.FindGameObjectsWithTag(EnemyTag);
		float shortestDistance = Mathf.Infinity;
		GameObject nearestEnemy = null;
		foreach (GameObject enemy in enemies){
			float distanceToEnemy = Vector3.Distance(transform.position, enemy.transform.position);
			if (distanceToEnemy < shortestDistance){
				shortestDistance = distanceToEnemy;
				nearestEnemy = enemy;
			}
		}

		if (nearestEnemy != null && shortestDistance <= range) {
			target = nearestEnemy.transform;
			targetEnemy = nearestEnemy.GetComponent<Enemy> ();
		} else {
			target = null;
		}

	}
	public static Player Instance;

	void Awake ()   
	{
		if (Instance == null)
		{
			DontDestroyOnLoad(gameObject);
			Instance = this;
		}
		else if (Instance != this)
		{
			Destroy (gameObject);
		}
	}
	void Start (){ 
		health = startHealth;
		speed = startSpeed;
		InvokeRepeating("UpdateTarget", 0f, 0.5f);
	}
	void Update(){
		if (health == 0) {
			Die ();
		}

		if (target == null) {
			
			return;
		}
		if (Vector3.Distance (transform.position, target.position) <= range&& cooltime<=0.0) {
			dmg (target);
			cooltime = startcooltime;
		}
		if (cooltime >= 0){
			cooltime -= Time.deltaTime;
		}

	}
	//ANGRIFF ENDE
}
