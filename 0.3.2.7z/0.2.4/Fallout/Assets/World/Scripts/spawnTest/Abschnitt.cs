﻿using UnityEngine;
using System.Collections;
using System; //This allows the IComparable Interface

//This is the class you will be storing
//in the different collections. In order to use
//a collection's Sort() method, this class needs to
//implement the IComparable interface.
public class Abschnitt : IComparable<Abschnitt>
{	
	public int anzahl;
	public GameObject[] enemies;
	public GameObject spawnpoint;

	public Abschnitt(int anzahl1, GameObject[] enemies1, GameObject spawnpoint1)
	{
		anzahl = anzahl1;
		enemies = enemies1;
		spawnpoint = spawnpoint1;
	}

	//This method is required by the IComparable
	//interface. 
	public int CompareTo(Abschnitt other)
	{
		if(other == null)
		{
			return 1;
		}

		//Return the difference in power.
		return anzahl - other.anzahl;
	}
}