﻿using UnityEngine;
using UnityEngine.UI;

public class PlayerStats : MonoBehaviour {

	[HideInInspector]
	public static int gold=0;
	public static int exp=0;
	public static int lvl=1;
	public static int wave;
	public static int tillLvl=10;

	public void addGold(int x){
		gold = gold + x;
	}

	public void addExp(int x){
		exp = exp + x;
	}
	void levelup(){
		lvl += 1;
	}
	// Update is called once per frame

	void Update(){
		if (exp >= tillLvl) {
			levelup();
			tillLvl *= 2;
		}
	}

}
//PlayerPrefs.SetInt("Score", 20);
//
//int score = PlayerPrefs.GetInt("Score");
//
//if(PlayerPrefs.HasKey("Score")){
//	int score = PlayerPrefs.GetInt("Score");
//}else{
//	Debug.Log("Non Existing Key");
//	score = 0;
//}