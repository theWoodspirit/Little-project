﻿using UnityEngine;
using UnityEngine.UI;

public class bogi : MonoBehaviour {
	// WERTE 
	[HideInInspector]
	public float startSpeed = 1;
	public float speed;
	public float atk = 5; 
	public float range;
	public float cooltime;
	public static bool fail=false; // mission nicht geschafft -> retry oder quit
	// WERTE ENDE


	//Variablen
	public string EnemyTag = "Enemy";
	private Transform target;
	private Enemy targetEnemy;
	//public Transform firePoint;
	//VARIABLEN ENDE

	void Start (){
		InvokeRepeating("UpdateTarget", 0f, 0.5f);
	}


	//ANGRIFF
	void UpdateTarget (){
		GameObject[] enemies = GameObject.FindGameObjectsWithTag(EnemyTag);
		float shortestDistance = Mathf.Infinity;
		GameObject nearestEnemy = null;
		foreach (GameObject enemy in enemies){
			float distanceToEnemy = Vector3.Distance(transform.position, enemy.transform.position);
			if (distanceToEnemy < shortestDistance){
				shortestDistance = distanceToEnemy;
				nearestEnemy = enemy;
			}
		}

		if (nearestEnemy != null && shortestDistance <= range) {
			target = nearestEnemy.transform;
			targetEnemy = nearestEnemy.GetComponent<Enemy> ();
		} else {
			target = null;
		}

	}
	void dmg(Transform enemy){
		Enemy e = enemy.GetComponent<Enemy>();

		if (e != null){
			e.TakeDamage(atk);
		}
	}


	void Update(){
		if (target == null) {
			return;
		}
		if (Vector3.Distance (transform.position, target.position) <= range && cooltime<=0.0) {
			dmg (target);
			cooltime = 1.0f;
		}
		cooltime -= Time.deltaTime;
	}
	//ANGRIFF ENDE
}

