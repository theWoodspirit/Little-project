﻿//using UnityEngine;
//using UnityEngine.EventSystems;
//
//public class Node : MonoBehaviour {
//
//	public Vector2 positionOffset;
//
//	[HideInInspector]
//	public GameObject turret;
//	[HideInInspector]
//	public TurretBlueprint turretBlueprint;
//	[HideInInspector]
//	public bool isUpgraded = false;
//
//	BuildManager buildManager;
//
//	void Start ()
//	{
//
//		buildManager = BuildManager.instance;
//	}
//
//	public Vector3 GetBuildPosition ()
//	{
//		return transform.position + positionOffset;
//	}
//		
//
//	void BuildTurret (TurretBlueprint blueprint)
//	{
//		if (PlayerStats.gold < blueprint.cost)
//		{
//			Debug.Log("Not enough money to build that!");
//			return;
//		}
//
//		PlayerStats.gold -= blueprint.cost;
//
//		GameObject _turret = (GameObject)Instantiate(blueprint.prefab, GetBuildPosition(), Quaternion.identity);
//		turret = _turret;
//
//		turretBlueprint = blueprint;
//
//		Debug.Log("Turret build!");
//	}
//
//	public void UpgradeTurret ()
//	{
//		if (PlayerStats.gold < turretBlueprint.upgradeCost) {
//			Debug.Log ("Not enough money to upgrade that!");
//			return;
//		}
//
//		PlayerStats.gold -= turretBlueprint.upgradeCost;
//
//		//Get rid of the old turret
//		Destroy (turret);
//
//		//Build a new one
//		GameObject _turret = (GameObject)Instantiate (turretBlueprint.upgradedPrefab, GetBuildPosition (), Quaternion.identity);
//		turret = _turret;
//		isUpgraded = true;
//		Debug.Log ("Turret upgraded!");
//
//	}
//		
//}
