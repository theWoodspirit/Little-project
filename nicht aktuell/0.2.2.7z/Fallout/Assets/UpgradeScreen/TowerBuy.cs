﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class TowerBuy : MonoBehaviour {

	public int cost;
	public bool haveMoney;
	public bool isplaced;
	public Text upgradeText;
	public GameObject tower;

	public void buyTower(){
		if (PlayerStats.gold < cost) {
			return;
		}
		Debug.Log ("Tower gekauft");
		PlayerStats.gold -= cost;
		Destroy (upgradeText);
		Instantiate (tower);
	}
}
