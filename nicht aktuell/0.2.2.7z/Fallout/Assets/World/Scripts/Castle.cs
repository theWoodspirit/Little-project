﻿using UnityEngine;
using UnityEngine.UI;

public class Castle : MonoBehaviour {
	// WERTE 
	[HideInInspector]
	public float startHealth = 100;
	private float health;
	public float range;
	public static bool fail=false; // mission nicht geschafft -> retry oder quit
	// WERTE ENDE

	public RectTransform healthBar;
	private bool isDead = false;
	public GameObject deathEffect;
	//VARIABLEN ENDE



	// VERLETZUNG
	public void CastleTakeDamage (float amount){
		health -= amount;
		//lebensleiste
		healthBar.sizeDelta = new Vector2(health, healthBar.sizeDelta.y);

		if (health <= 0 && !isDead)
		{
			Die();
		}
	}

	void Die (){
		isDead = true;
		fail = true;
	//	GameObject effect = (GameObject)Instantiate(deathEffect, transform.position, Quaternion.identity);
	//	Destroy(effect, 5f);
		Destroy(gameObject);
	}
	// VERLETZUNG ENDE
	public static Castle Instance;

	void Awake ()   
	{
		if (Instance == null)
		{
			DontDestroyOnLoad(gameObject);
			Instance = this;
		}
		else if (Instance != this)
		{
			Destroy (gameObject);
		}
	}
	void Start (){ 
		health = startHealth;
	}
	void Update(){
		if (health > 0) {
			return;
		}else{
			Die();
		}

	}
	//ANGRIFF ENDE
}
