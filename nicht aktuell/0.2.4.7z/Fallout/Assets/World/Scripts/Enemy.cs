﻿using UnityEngine;
using UnityEngine.UI;

public class Enemy : MonoBehaviour {

	// GEGNER STATS
	public float startSpeed = 1f;
	[HideInInspector]
	public float speed;
	public float startHealth = 100;
	private float health;
	public float atk;
	public float range;
	public int wert=1;
	public int xpWert=1;
	// GEGNER STATS ENDE 



	// VARIABLEN
	public GameObject deathEffect;
	[Header("Unity Stuff")]
	private bool isDead = false;
	public Transform held; 
	public Transform castle;
	public RectTransform healthBar;


	// VARIABLEN ENDE

	void Start ()
	{
		speed = startSpeed;
		health = startHealth;
	}

	// LEIDEN
	public void TakeDamage (float amount)
	{
		health -= amount;
		//lebensleiste
		healthBar.sizeDelta = new Vector2(health, healthBar.sizeDelta.y);
		if (health <= 0 && !isDead){
			Die();
		}
	}

	public void Slow (float pct)
	{
		speed = startSpeed * (1f - pct);
	}

	void Die ()
	{
		isDead = true;

		PlayerStats.gold += wert;
		PlayerStats.exp += xpWert;
		WaveSpawner.EnemiesAlive--;
		Destroy(gameObject);

	}
	// LEIDEN ENDE


	//ANGRIFF
	void dmg(Transform hero){
		Player h = hero.GetComponent<Player>();

		if (h != null){
			h.HeroTakeDamage(atk);
		}
	}

	//ANGRIFF SCHLOSS
	void dmgCastle(Transform castle){
		Castle c = castle.GetComponent<Castle>();

		if (c != null){
			c.CastleTakeDamage(atk);
		}
	}


	void Update(){

		if (health == 0) {
			Die ();
		}

		if (held != null) {

			Vector3 displacement = held.position - transform.position;
			displacement = displacement.normalized;
			if (Vector2.Distance (held.position, transform.position) >= range) {
				transform.position += (displacement * speed * Time.deltaTime);
			} else {
				//Debug.Log ("update enemy");
				dmg (held);
			}

		}
		if (castle == null) {
			return;
		}

		else {
			Vector3 displacement = castle.position -transform.position;
			displacement = displacement.normalized;
			if (Vector2.Distance (castle.position, transform.position) >= range) {
				transform.position += (displacement * speed * Time.deltaTime);

			}else{
				dmgCastle (castle);
			}

		} 
	}
}
