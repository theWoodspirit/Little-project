﻿using System;

namespace AssemblyCSharp
{
	public class EmptyClass
	{
		public EmptyClass ()
		{
		}
	}
}

