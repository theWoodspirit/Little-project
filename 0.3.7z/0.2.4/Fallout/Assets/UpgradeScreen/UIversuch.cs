﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class UIversuch : MonoBehaviour {
	public GameObject TowerUI;
	public GameObject BogiUI;

	public void towerUpgrade(){
		TowerUI.SetActive(true);
	}
	public void exitTowerUpgrade(){
		TowerUI.SetActive (false);
	}

	public void BogiUpgrade(){
		BogiUI.SetActive(true);
	}
	public void exitBogiUpgrade(){
		BogiUI.SetActive (false);
	}
}
