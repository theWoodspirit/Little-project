﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class goldUI : MonoBehaviour {

	// Use this for initialization
	public Text goldUItext;

	// Update is called once per frame
	void Update () {
		goldUItext.text = "Gold: " + PlayerStats.gold.ToString ();
	}
}
