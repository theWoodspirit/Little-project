﻿using UnityEngine;
using UnityEngine.SceneManagement;

public class MainMenu : MonoBehaviour {

	public string levelToLoad = "MainLevel";
	public string upgradeScn = "UpgradeScreen";
	public string mainMenu = "Menu";

	public SceneFading sceneFader;

	public void Play ()
	{
		sceneFader.FadeTo(levelToLoad);
	}

	public void upgrade(){
		sceneFader.FadeTo(upgradeScn);	
	
	}
	public void toMenu(){
		sceneFader.FadeTo (mainMenu);
	}

	public void Quit ()
	{
		Debug.Log("Exciting...");
		Application.Quit();
	}

}
