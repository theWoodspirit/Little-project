﻿using UnityEngine;
using UnityEngine.UI;

public class Player : MonoBehaviour {
	// WERTE 

	[HideInInspector]
	public float startSpeed = 5f;
	public float speed;

	public static float startHealth = 100;
	public static float health;

	public static float atk = 5; 
	public static float range=8;

	public float cooltime;
	public float startcooltime=0.5f;
	// WERTE ENDE


	//VARIABLEN ENDE
	public GameObject deathEffect;
	public RectTransform healthBar;
	public bool heldtod = false;
	public string EnemyTag = "Enemy";
	private Transform target;
	private Enemy targetEnemy;
	// VARIABLEN ENDE

	// VERLETZUNG
	public void HeroTakeDamage (float amount){
		health -= amount;
		// lebensleiste anzeigen
		healthBar.sizeDelta = new Vector2(health/startHealth * 100, healthBar.sizeDelta.y);
		Debug.Log ("hero take damage");
		if (health <= 0 && !heldtod){
			Die();
		}
	}

	public void Slow (float pct){
		speed = startSpeed * (1f - pct);
	}

	void Die (){
		heldtod = true;
		//GameObject effect = (GameObject)Instantiate(deathEffect, transform.position, Quaternion.identity);
		//Destroy(effect, 5f);
		Destroy(gameObject);
	}
	// VERLETZUNG ENDE

	//ANGRIFF
	void dmg(Transform enemy, float dmg){
		Enemy e = enemy.GetComponent<Enemy>();

		if (e != null){
			e.TakeDamage(dmg);
		}
	}

	public static int poisonAtk=100; 
	public static float poisonRange=15;
	public static float startPoisonCooltime=2;
	public static float poisonCooltime=2;

	public void poisoncloud() {
		if (poisonCooltime >= 0.0) {
			return;
		} else {
			GameObject[] enemies = GameObject.FindGameObjectsWithTag (EnemyTag);
			foreach (GameObject enemy in enemies) {
				if (Vector2.Distance (transform.position, enemy.transform.position) <= poisonRange) {
					dmg (enemy.transform, poisonAtk);
					poisonCooltime = startPoisonCooltime;
				}
			}
		}
	}

	void UpdateTarget (){
		GameObject[] enemies = GameObject.FindGameObjectsWithTag(EnemyTag);
		float shortestDistance = Mathf.Infinity;
		GameObject nearestEnemy = null;
		foreach (GameObject enemy in enemies){
			float distanceToEnemy = Vector3.Distance(transform.position, enemy.transform.position);
			if (distanceToEnemy < shortestDistance){
				shortestDistance = distanceToEnemy;
				nearestEnemy = enemy;
			}
		}

		if (nearestEnemy != null && shortestDistance <= range) {
			target = nearestEnemy.transform;
			targetEnemy = nearestEnemy.GetComponent<Enemy> ();
		} else {
			target = null;
		}

	}
	public static Player Instance;

	void Awake ()   
	{
		if (Instance == null)
		{
			DontDestroyOnLoad(gameObject);
			Instance = this;
		}
		else if (Instance != this)
		{
			Destroy (gameObject);
		}
	}
	void Start (){ 
		health = startHealth;
		speed = startSpeed;
		InvokeRepeating("UpdateTarget", 0f, 0.5f);
	}
	void Update(){
		if (health == 0) {
			Die ();
		}

		if (target == null) {
			
			return;
		}
		if (Vector3.Distance (transform.position, target.position) <= range&& cooltime<=0.0) {
			dmg (target,atk);
			cooltime = startcooltime;
		}
		if (cooltime >= 0){
			cooltime -= Time.deltaTime;
		}
		if (poisonCooltime >= 0){
			poisonCooltime -= Time.deltaTime;
		}

	}
	//ANGRIFF ENDE
}
