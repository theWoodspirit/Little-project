﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class TowerBuy : MonoBehaviour {

	public int cost=3;

	public static bool buyed;
	public bool haveMoney;
	public bool isplaced=false;

	public Text upgradeText;
	public GameObject tower;
	public Button BuyButton;

	public void buyTower(){
		if (PlayerStats.gold < cost) {
			return;
		}
		Debug.Log ("Tower gekauft");
		PlayerStats.gold -= cost;
		Destroy (upgradeText);
		Instantiate (tower);
		isplaced = true;
		buyed = true;
		Destroy (BuyButton);
	}

	public void upgradeTower(){
		if (PlayerStats.gold < cost) {
			return;
		}
		Debug.Log ("Tower geupgradet");
		PlayerStats.gold -= cost;
		cost += 3;
		Turm.atk += 3;
	}

	void Awake(){
		if (buyed == true) {
			Destroy (upgradeText);
			Destroy (BuyButton);
			return;
		}
	}
}