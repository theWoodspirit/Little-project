﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class UIversuch : MonoBehaviour {
	public GameObject TowerUI;
	public GameObject BogiUI;
	public GameObject CastleUI;
	public GameObject HeroUI;

	public void towerUpgrade(){
		TowerUI.SetActive(true);
	}
	public void exitTowerUpgrade(){
		TowerUI.SetActive (false);
	}

	public void BogiUpgrade(){
		BogiUI.SetActive(true);
	}
	public void exitBogiUpgrade(){
		BogiUI.SetActive (false);
	}
	public void CastleUpgrade(){
		CastleUI.SetActive(true);
	}
	public void exitCastleUpgrade(){
		CastleUI.SetActive (false);
	}
	public void HeroUpgrade(){
		HeroUI.SetActive(true);
	}
	public void exitHeroUpgrade(){
		HeroUI.SetActive (false);
	}
}
