﻿using UnityEngine;

[System.Serializable]
public class Wave {

	public GameObject enemy;
	public int anzahl;
	public float rate;

	// public int Abschnitte=5;
}
